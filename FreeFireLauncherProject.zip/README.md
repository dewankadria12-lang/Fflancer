# Game Launcher (Android project)

A small Android Studio starter project with:
- A RUN button that tries to launch the installed official Free Fire or Free Fire MAX app.
- A user-enabled floating button that plays a short built-in beep when tapped.
- A Stop button to remove the floating control.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish and install any requested Android SDK platform (API 35).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location when the build finishes.

## Install on your phone
Transfer the generated APK to your Android phone and open it. If prompted, allow installing apps from that source. Only install APKs you built or trust.

## Notes
- The project does not modify Free Fire, automate gameplay, or provide cheats.
- The floating control requires the Android "Display over other apps" permission, which you must enable manually.
- Some Android versions restrict overlays or background behavior. If the floating button doesn't appear, reopen the launcher and enable it again.
- Free Fire package IDs can vary by region/version. If RUN says the game wasn't found, install the official game or adjust the package IDs in `MainActivity.kt`.
- This starter project uses a generated system beep, not an imported music/audio file.
