package com.example.freefirelauncher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(18, 12, 28))
        }
        val title = TextView(this).apply {
            text = "GAME LAUNCHER"
            textSize = 28f
            setTextColor(Color.rgb(220, 150, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Open your installed game and use a floating sound button."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 28)
        }
        val run = Button(this).apply {
            text = "RUN  ▶"
            textSize = 20f
            setOnClickListener { runGame() }
        }
        val overlay = Button(this).apply {
            text = "Enable floating sound button"
            setOnClickListener { enableFloatingButton() }
        }
        val stop = Button(this).apply {
            text = "Stop floating button"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingSoundService::class.java))
                Toast.makeText(this@MainActivity, "Floating button stopped", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(run, LinearLayout.LayoutParams(-1, -2))
        root.addView(overlay, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        setContentView(root)
    }

    private fun enableFloatingButton() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingSoundService::class.java))
            Toast.makeText(this, "Floating button enabled", Toast.LENGTH_SHORT).show()
        } else {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
        }
    }

    @Deprecated("Legacy result callback used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingSoundService::class.java))
        }
    }

    private fun runGame() {
        // Common Free Fire package IDs. The installed game variant determines which works.
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                return
            }
        }
        Toast.makeText(this,
            "Free Fire was not found. Install the official game first, then try again.",
            Toast.LENGTH_LONG).show()
    }
}
